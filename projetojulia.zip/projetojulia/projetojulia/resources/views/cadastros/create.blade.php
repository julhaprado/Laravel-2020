<!DOCTYPE html>
<html lang="pt-br">
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title> Cadastro </title>
</head>
<body> 
	<center><form action="{{ route('registrar_cadastro') }}" method="POST">
		@csrf
		<label for="">Nome</label><br />
		<input type="text" name="nome"><br />
		<label for="">Idade</label><br />
		<input type="text" name="idade"><br />
		<label for="">Endereco</label><br />
		<input type="text" name="endereco"><br />
		<label for="">Telefone</label><br />
		<input type="text" name="telefone"><br />
		<label for="">Email</label><br />
		<input type="text" name="email"><br />
		<button>Cadastrar</button>
	</form></center>
</body>
</html>